import java.util.List;
import java.util.Collections;

/**
 * Class Ghost
 * A ghost in the castle.
 * 
 * @author Olaf Chitil
 * @version 3/2/2020
 */

public class Ghost extends Character
{
    private String description;

    /**
     * Constructor initialising location and description.
     * Pre-condition: location not null.
     * Pre-condition: description not null.
     */
    public Ghost(Room loc, String desc)
    {
        super(loc);
        // ToDo
    }

    /**
     * Return the description.
     */
    public String toString()
    {
        return null; // ToDo
    }

    /**
     * Go to a random room.
     * @param rooms all rooms available
     * Pre-condition: the list is not empty.
     */
    public void goRandom(List<Room> rooms)
    {
        // ToDo
    }
}
