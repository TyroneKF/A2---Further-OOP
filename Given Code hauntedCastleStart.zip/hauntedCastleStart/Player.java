/**
 * Class Player
 * A single object represents the single player.
 * 
 * @author Olaf Chitil
 * @version 3/2/2020
 */

public class Player extends Character
{
    /**
     * Constructor, taking start room and goal room.
     * Pre-condition: start location is not null.
     */
    public Player(Room start, Room goal)
    {
        super(start);
    }
    
    /**
     * Check whether time limit has been reached.
     */
    public boolean isAtTimeLimit()
    {
        return false; // ToDo
    }
    
    /**
     * Check whether goal has been reached.
     */
    public boolean isAtGoal()
    {
        return false; // ToDo
    }
    
    /**
     * Return a description.
     */
    public String toString()
    {
        return "you";
    }
}
