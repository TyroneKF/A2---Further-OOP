import java.util.List;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Collections;
import java.util.ArrayList;
import java.lang.Math;

/**
 * Class SolidGhost
 * A solid ghost in the castle.
 * 
 * @author Olaf Chitil
 * @version 4/2/2020
 */

public class SolidGhost extends Ghost
{   private Direction[] tempDirections;
    
    List<Direction> directions;
    /**
     * Constructor initialising location and description.
     * Pre-condition: location not null.
     * Pre-condition: description not null.
     */
    public SolidGhost(Room loc, String desc)
    {   super(loc, desc);
        assert desc != null : "SolidGhost.SolidGhost gets null description";
        assert loc != null : "SolidGhost.SolidGhost gets null Room";
    }

    /**
     * Go to a random neighbouring room.
     * If there is no neighbour, then stay in current room.
     * @param rooms all rooms available - actually ignored
     */
    public void goRandom(List<Room> rooms)
    {   assert rooms != null : "SolidGhost.goRandom gets null rooms";
               
        Direction[] tempDirections = {Direction.NORTH, Direction.SOUTH, Direction.EAST,Direction.WEST, Direction.UP,Direction.DOWN};
        directions = Arrays.asList(tempDirections);
        
        ArrayList<Direction> movements = new ArrayList<Direction>();
        
        Direction dir;
        Direction finalDir;
        boolean state = true;
        for (int index =0; index<=directions.size()-1; index++)
        {   dir = directions.get(index);
            if(getLocation().getExit(dir)!= null)
            {
                movements.add(directions.get(index));
            }
            
        }   
        
        if(movements.size()>0)
        {
            int randomNumber = (int)(Math.random() * (( (movements.size()-1))+1));
            finalDir = movements.get(randomNumber);
            move(getLocation().getExit(finalDir));
            
            movements.clear();
            
        }
    }
}
