import java.util.List;
import java.util.Collections;
import java.lang.Math; 
/**
 * Class Ghost
 * A ghost in the castle.
 * 
 * @author Tyrone Friday
 * @version 18/2/2020
 */

public class Ghost extends Character
{
    private String description;

    /**
     * Constructor initialising location and description.
     * Pre-condition: location not null.
     * Pre-condition: description not null.
     */
    public Ghost(Room loc, String desc)
    {
        super(loc);
        assert loc != null : "Ghost.Ghost gets null  Room loc ";
        assert desc != null : "Ghost.Ghost gets null  String desc";
        description = desc;
    }

    /**
     * Return the description.
     */
    public String toString()
    {
        return description;
    }

    /**
     * Go to a random room.
     * @param rooms all rooms available
     * Pre-condition: the list is not empty.
     */
    public void goRandom(List<Room> rooms)
    {   assert rooms != null : "Ghost.goRandom gets null List<Room> rooms ";
        if(rooms.size()>=1)
        { 
            // int minRange = 0;
            // int maxRange= rooms.size();
            // int roomRange = (maxRange-minRange)+1;
            // int randomRoom = (int) (Math.random()*roomRange)+minRange;
            // move(rooms.get(randomRoom));
            
            int randomNumber = (int)(Math.random() * (( (rooms.size()-1))+1));
            move(rooms.get(randomNumber));
        }
    }
}
