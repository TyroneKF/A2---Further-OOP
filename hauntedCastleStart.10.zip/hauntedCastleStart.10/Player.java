/**
 * Class Player
 * A single object represents the single player.
 * 
 *  @author Olaf Chitil
 * @version 4/2/2020
 */

public class Player extends Character
{   
    private Room goal;
    private int moves =0;
    private int limit = 12;
    /**
     * Constructor, taking start room and goal room.
     * Pre-condition: start location is not null.
     */
    public Player(Room start, Room goal)
    {   super(start);
        assert start != null : "Player.Player gets null  Room start";
        assert goal != null : "Player.Player gets null Room  goal";
        this.goal = goal;
    }

    /**
     * Check whether time limit has been reached.
     */
    public boolean isAtTimeLimit()
    {   
        moves +=1;
        if (moves == limit)
        { 
            return true;
        }
        
        return false; // ToDo
    }

    /**
     * Check whether goal has been reached.
     */
    public boolean isAtGoal()
    {   
        if (getLocation() == goal)
        {
            return true;
        }

        return false; // ToDo
    }

    /**
     * Return a description.
     */
    public String toString()
    {   
        return "you";
    }
}
